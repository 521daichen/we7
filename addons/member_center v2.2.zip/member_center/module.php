<?php
/**
 * 会员中心模块定义
 *
 * @author 橙橙同学
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Member_centerModule extends WeModule {



}