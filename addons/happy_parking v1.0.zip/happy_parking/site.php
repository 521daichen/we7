<?php
/**
 * 智慧停车系统模块微站定义
 *
 * @author 橙橙同学
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Happy_parkingModuleSite extends WeModuleSite {

	public function doMobileParkingSetting() {
		//这个操作被定义用来呈现 功能封面
	}
	public function doWebParkingLog() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebParkingScore() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebParingMember() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebParkingConfig() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebParkingInfo() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}

}